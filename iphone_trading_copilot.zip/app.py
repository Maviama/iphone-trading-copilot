import streamlit as st
import pandas as pd
import yfinance as yf
from datetime import time
import pytz

ET = pytz.timezone("America/New_York")

st.set_page_config(page_title="AI Trading Copilot", page_icon="📈", layout="centered")

st.title("📈 AI Trading Copilot")
st.caption("Opening Strength Detector for SanDisk, Broadcom, Marvell and Nvidia")

tickers = st.multiselect(
    "Stocks to monitor",
    ["SNDK", "AVGO", "MRVL", "NVDA"],
    default=["SNDK", "AVGO", "MRVL", "NVDA"],
)

def vwap(df):
    typical = (df["High"] + df["Low"] + df["Close"]) / 3
    return (typical * df["Volume"]).cumsum() / df["Volume"].cumsum()

def analyse(ticker):
    df = yf.download(
        ticker,
        period="5d",
        interval="1m",
        prepost=True,
        progress=False,
        auto_adjust=False,
    )

    if df.empty:
        return {"Ticker": ticker, "Signal": "ERROR", "Action": "No data returned"}

    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)

    df = df.dropna()
    df.index = df.index.tz_convert(ET)
    today = df.index[-1].date()

    regular = df[
        (df.index.date == today) &
        (df.index.time >= time(9, 30)) &
        (df.index.time <= time(16, 0))
    ].copy()

    if len(regular) < 30:
        return {
            "Ticker": ticker,
            "Signal": "WAIT",
            "Action": "Run after 3:00pm UK time, once the first 30 minutes of US trading are available.",
        }

    prev_regular = df[
        (df.index.date < today) &
        (df.index.time >= time(9, 30)) &
        (df.index.time <= time(16, 0))
    ]

    prev_close = float(prev_regular["Close"].iloc[-1])
    open_price = float(regular["Open"].iloc[0])
    price = float(regular["Close"].iloc[-1])
    gap_pct = (open_price - prev_close) / prev_close * 100

    first_30 = regular.iloc[:30]
    high_30 = float(first_30["High"].max())
    low_30 = float(first_30["Low"].min())

    regular["VWAP"] = vwap(regular)
    current_vwap = float(regular["VWAP"].iloc[-1])

    above_vwap = price > current_vwap
    broke_high = price > high_30
    broke_low = price < low_30
    faded = price < open_price

    if gap_pct > 1 and above_vwap and broke_high and price > open_price:
        signal = "🟢 STRONG GAP-AND-GO"
        action = "Hold. Do not sell the trading sleeve yet."
        confidence = 85
    elif gap_pct > 1 and above_vwap and not broke_high:
        signal = "🟡 GAP BUT FADING"
        action = "Prepare to sell if price loses VWAP."
        confidence = 65
    elif gap_pct > 1 and (not above_vwap or broke_low or faded):
        signal = "🔴 GAP-AND-FADE"
        action = "Consider selling the trading sleeve, especially near resistance."
        confidence = 80
    elif price < current_vwap:
        signal = "🔴 WEAK INTRADAY"
        action = "Avoid buying. Sellers have control."
        confidence = 70
    else:
        signal = "⚪ NO CLEAR EDGE"
        action = "Do nothing."
        confidence = 55

    return {
        "Ticker": ticker,
        "Price": round(price, 2),
        "Gap %": round(gap_pct, 2),
        "VWAP": round(current_vwap, 2),
        "Opening High": round(high_30, 2),
        "Opening Low": round(low_30, 2),
        "Signal": signal,
        "Action": action,
        "Confidence": f"{confidence}%",
    }

if st.button("Refresh signals"):
    results = [analyse(t) for t in tickers]
    for r in results:
        st.subheader(r["Ticker"])
        st.write(f"**Signal:** {r.get('Signal')}")
        st.write(f"**Action:** {r.get('Action')}")
        cols = st.columns(3)
        if "Price" in r:
            cols[0].metric("Price", r["Price"])
            cols[1].metric("Gap %", r["Gap %"])
            cols[2].metric("VWAP", r["VWAP"])
            st.write(f"Opening range: **{r['Opening Low']} – {r['Opening High']}**")
            st.write(f"Confidence: **{r['Confidence']}**")
        st.divider()

st.info("Best time to use: after 3:00pm UK time. This is decision support, not automatic trading.")
