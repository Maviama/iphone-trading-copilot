# iPhone Trading Copilot

This is a phone-friendly web dashboard for your Opening Strength Detector.

## What it does

It monitors:

- SNDK
- AVGO
- MRVL
- NVDA

It classifies the open as:

- 🟢 Strong gap-and-go
- 🟡 Gap but fading
- 🔴 Gap-and-fade
- 🔴 Weak intraday
- ⚪ No clear edge

## How to run on your phone

The easiest way is to deploy it to **Streamlit Community Cloud**.

### Step 1

Create a free GitHub account if you do not already have one.

### Step 2

Create a new GitHub repository, for example:

`iphone-trading-copilot`

Upload these two files:

- `app.py`
- `requirements.txt`

### Step 3

Go to Streamlit Community Cloud and create a new app from that GitHub repository.

Set the main file path to:

`app.py`

### Step 4

Open the Streamlit link on your iPhone and save it to your Home Screen.

## When to use it

Use it after **3:00pm UK time**, because US regular trading opens at **2:30pm UK time** during UK summer time.

## SanDisk rule

- 🟢 Strong gap-and-go: do not sell your trading sleeve yet.
- 🟡 Gap but fading: prepare to sell if price loses VWAP.
- 🔴 Gap-and-fade: consider selling 1 trading share.
- ⚪ No clear edge: do nothing.
